package mobilne.dex.service.impl;

import mobilne.dex.service.DexService;

import com.android.dx.command.dexer.Main;

public class DexServiceImpl implements DexService {
	public byte[] createDexedJarFromFile(String filename) {
		System.out.println("DexService: DEXing " + filename);
		byte[] dexed = Main.createDexJar(filename);
		return dexed;
	}
}