package mobilne.dex.service;

public interface DexService {
	public byte[] createDexedJarFromFile(String filename);
}
